document.addEventListener("DOMContentLoaded", () => {
    fetchProducts();
});

function fetchProducts() {
    // Sample products data
    const products = [
        {
            name: "Product 1",
            description: "Description for Product 1",
            price: 29.99,
            imageUrl: "https://via.placeholder.com/200"
        },
        {
            name: "Product 2",
            description: "Description for Product 2",
            price: 39.99,
            imageUrl: "https://via.placeholder.com/200"
        },
        {
            name: "Product 3",
            description: "Description for Product 3",
            price: 49.99,
            imageUrl: "https://via.placeholder.com/200"
        }
    ];

    const productsContainer = document.getElementById('products');
    products.forEach(product => {
        const productElement = document.createElement('div');
        productElement.className = 'product';

        const productImage = document.createElement('img');
        productImage.src = product.imageUrl;
        productImage.alt = product.name;

        const productName = document.createElement('h2');
        productName.textContent = product.name;

        const productDescription = document.createElement('p');
        productDescription.textContent = product.description;

        const productPrice = document.createElement('p');
        productPrice.textContent = '$${product.price}';

        productElement.appendChild(productImage);
        productElement.appendChild(productName);
        productElement.appendChild(productDescription);
        productElement.appendChild(productPrice);

        productsContainer.appendChild(productElement);
    });
}